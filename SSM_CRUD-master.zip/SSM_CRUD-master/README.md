# SSM_CRUD

这里给大家介绍的是SSM_CRUD的demo项目整合，CRUD(create 创建、retrieve 查询、update 更新、delete 删除)也是SSM框架中最为常用的工程功能。
对ssm入门整合还是挺有帮助的、希望大家点点小手可以多给几个star哦 ，谢谢啦）.具体工程的搭建可以查看我的博客：http://blog.csdn.net/w_x_s_h_h/article/details/79170012

ssm_crud 项目的功能点：

1、分页

2、数据校验（Jquery前端校验+JSR303后端校验）

3、ajax

4、Rest风格的URI：使用HTTP协议请求方式的动词，来表示对资源的操作（GET(查询)、POST(新赠)、PUT(修改)、DELETE(删除)）

技术点：

1、基础框架-ssm(SpringMVC+Spring+Mybatis)

2、数据库-MySQL

3、前端框架-bootstrap快速搭建简洁美观的界面

4、项目的依赖管理-Maven

5、分页-pagehelper

6、mybatis Generator-逆向工程







![这里写图片描述](http://img.blog.csdn.net/20180126110146302?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvd194X3NfaF9o/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)

2.数据库在ssm_crud.sql
